# Implemented enhancements

## Reliability fixes

- Preserve assistant tool-call metadata in Ollama follow-up messages so tool results remain associated with the assistant's preceding request.
- Use Jarvis's shared `StreamingSentenceChunker` for Ollama callback delivery rather than maintaining a separate punctuation splitter.
- Reject zero, negative, boolean, and non-integer `AudioRingBuffer` capacities at construction time.
- Add focused mocked/unit regression coverage for Ollama message history, shared chunking, and invalid audio capacities.
- Declare the existing `py-spy` diagnostics dependency so a clean environment can install the profiler executable expected by the diagnostics tests.

## Existing provider work in this worktree

- Replace the retired GitHub Models inference API path with a GitHub Copilot CLI bridge configured to use a repository custom agent with no allowed tools and explicit shell/write denials.
- Hand off Antigravity quota/rate-limit failures to Copilot CLI only when the error is recognized as quota-related and the CLI is available.
- Preserve quota exhaustion across subsequent model-cascade failures and avoid returning generic success-shaped text for unhandled failures.

The Copilot CLI path has not been live-tested in this environment because the CLI is unavailable. Its mocked tests are covered by the full test suite.

## Deferred work

The open findings and recommended sequence are in [AUDIT_REPORT.md](./AUDIT_REPORT.md) and [ROADMAP.md](./ROADMAP.md). In particular, the shell safety gate, URL/redirect restrictions, screenshot path confinement, COM lifecycle, HUD thread affinity, and process-launch cleanup still need implementation and regression tests.
