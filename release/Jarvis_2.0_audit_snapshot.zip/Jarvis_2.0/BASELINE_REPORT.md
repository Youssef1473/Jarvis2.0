# Baseline report

## Environment

- Windows workspace: `C:\Users\Youssef\Projects\Jarvis_2.0`
- Python environment: `.venv\Scripts\python.exe`
- Test runner: Python `unittest`
- Worktree was not clean at baseline: it already contained the uncommitted provider/Copilot bridge changes. Those edits were preserved.

## Baseline result

Command:

```powershell
.\.venv\Scripts\python.exe -m unittest discover tests
```

Result captured before the audit-scoped reliability changes:

- **251 tests passed**
- Runtime: **113.986 seconds**
- Exit status: **0**

This is a test baseline for the existing worktree, not a comparison against a clean commit or a claim that all hardware and external-provider integrations are available.

