# Jarvis audit findings

## Scope and method

This is a focused audit of the attachment-driven changes and the highest-risk findings surfaced during the Council review. It is not a line-by-line security audit of every tracked file, and it is not a security sign-off. Existing assertions in the supplied material were treated as claims and checked against repository behavior; in particular, `requirements.txt` already includes `mcp>=1.0.0`.

## Findings

| Priority | Status | Area | Finding |
|---|---|---|---|
| High | Open | Direct shell execution | `execute_powershell()` does not apply the internal `SafetyGate` check. The background-task path already checks commands through `BackgroundTaskManager`; that check should remain there rather than be duplicated in its wrapper. The denylist is not a shell sandbox. |
| High | Open | Browser/research networking | URL checks do not resolve hostnames and do not robustly reject private resolved addresses or private redirect destinations. Browser navigation also permits redirects and subresource requests. A URL pre-check cannot prevent DNS rebinding or browser-originated private requests; enforce network egress policy for a strong SSRF boundary. |
| High | Open | Screenshot output | `capture_webpage_screenshot()` accepts a caller-controlled output filename that can escape the intended data directory, including through path traversal or symlink resolution. |
| Medium | Open | Untrusted web content | Research output includes source-derived titles, snippets, and extracted text without a sufficiently explicit, escaped untrusted-data boundary. Delimiters alone do not prevent prompt injection. |
| Medium | Open | COM/SAPI lifecycle | Timer and watchdog speech workers initialize COM without guaranteed uninitialization and start asynchronous SAPI speech without waiting for completion. |
| Medium | Open | HUD thread affinity | Tk operations can be invoked from callers other than the thread that owns the Tk event loop. UI mutations and shutdown should be marshalled to that thread. |
| Medium | Open | Process launch | `project_manager.py` passes an argument list to `Popen` while also enabling `shell=True`; remove the unnecessary shell layer and add a mocked regression test. |
| Medium | Deferred | MCP | `mcp_manager.py` does not connect to servers or discover/invoke tools. Configuration and the `mcp` dependency exist, but a working client needs an explicit transport, lifecycle, and tool-dispatch contract before implementation. |
| Medium | Fixed | Ollama conversation history | Assistant `tool_calls` metadata was dropped while rebuilding follow-up messages. It is now preserved alongside the matching tool result. |
| Low | Fixed | Ollama streaming | Ollama used a weaker, duplicated punctuation splitter. It now uses `StreamingSentenceChunker` and flushes remaining text through the shared implementation. |
| Low | Fixed | Audio buffer | `AudioRingBuffer` accepted non-positive and non-integer capacities. Construction now rejects invalid capacities with `ValueError`. |
| Low | Fixed | MCP documentation | README now describes MCP as configuration-only until the transport and tool discovery are implemented. |
| Low | Fixed | Diagnostics dependency | The checked-in requirements omitted `py-spy`, although the diagnostics implementation and tests require its executable. It is now declared and the Quick Start documents dependency installation. |

## Release posture

The repository snapshot is useful for review and testing, but it is **not production-security-certified** while the open High-priority findings remain. The URL checks proposed for a future fix must fail closed on resolution errors, reject any non-global resolved address, handle redirects at each hop, and clearly document the remaining DNS-rebinding/browser-subresource limitations.
